// resources/js/plugins/vue_router.js
// Vue Router
import { createRouter, createWebHistory } from 'vue-router';
import { markRaw } from 'vue';
import { useAuthStore } from '@/plugins/authStore.js'; // Clean absolute alias

// Global Layout Sheets Scaffolds
import AuthenticatedLayout from '@/layouts/AuthenticatedLayout.vue';
import LoginLayout from '@/layouts/LoginLayout.vue';

// 1. AUTH FLOW VIEWS (Moved from pages/)
import Login from '@/views/auth/Login.vue';
import ForgotPassword from '@/views/auth/ForgotPassword.vue';
import ResetPassword from '@/views/auth/ResetPassword.vue';

// 2. DATASET SPREADSHEET MONITORING VIEWS (Moved from components/tables/ and suffixes stripped)
import Connections from '@/views/datasets/Connections.vue';
import Consortia from '@/views/datasets/Consortia.vue';
import CredentialsAudit from '@/views/datasets/CredentialsAudit.vue';
import Credentials from '@/views/datasets/Credentials.vue';
import HarvestLog from '@/views/datasets/HarvestLog.vue';
import HarvestQueue from '@/views/datasets/HarvestQueue.vue';
import InstitutionGroups from '@/views/datasets/InstitutionGroups.vue';
import Institutions from '@/views/datasets/Institutions.vue';
import InstitutionTypes from '@/views/datasets/InstitutionTypes.vue';
import Platforms from '@/views/datasets/Platforms.vue';
import Roles from '@/views/datasets/Roles.vue';
import Users from '@/views/datasets/Users.vue';

// 3. SYSTEM INFRASTRUCTURE & SETTINGS PANELS (Moved from components/panels/)
import AccountSettings from '@/views/admin/AccountSettings.vue';
import CCPlusApi from '@/views/admin/CCPlusApi.vue';
import MailSettings from '@/views/admin/MailSettings.vue';
import ManualHarvest from '@/views/admin/ManualHarvest.vue';
import Reporting from '@/views/admin/Reporting.vue';
import ServerSettings from '@/views/admin/ServerSettings.vue';

// Pinia Datastore Pipeline
import { createPinia } from 'pinia';
import piniaPluginPersistedState from "pinia-plugin-persistedstate";

export const pinia = createPinia();
pinia.use(piniaPluginPersistedState);

// Routes configuration layout matrix
const routes = [
    /* ----------------------------------------------------
        Unauthenticated Routes  (LoginLayout)
    ------------------------------------------------------- */
    {
      path: '/', name: 'Home', component: Login, children: [],
      meta: { title: 'Login', layout: LoginLayout, role: 'Guest', level: 0 },
    },
    {
      path: '/login', name: 'Login', component: Login, children: [],
      meta: { title: 'Login', layout: LoginLayout, role: 'Guest', level: 0 },
    },
    {
      path: '/logout', name: 'Logout', component: Login, children: [],
      meta: { title: 'Logout', layout: LoginLayout, role: 'Guest', level: 0 },
    },
    { 
      path: '/forgotPassForm', name: 'ForgotPassword', component: ForgotPassword, children: [],
      meta: { title: 'Forgot Password', layout: LoginLayout, role: 'Guest', level: 0 }
    },
    { 
      path: '/resetPassForm', name: 'ResetPassword', component: ResetPassword, children: [],
      props: route => ({ token: route.query.token, key: route.query.key }),
      meta: { title: 'Reset Password', layout: LoginLayout, role: 'Guest', level: 0 }
    },

    /* ----------------------------------------------------
       Authenticated Layout Routes
    ------------------------------------------------------- */
    {
      path: '/consortia', name: 'Consortia', component: markRaw(Consortia), children: [],
      meta: { title: 'Consortia', layout: AuthenticatedLayout, role: 'ServerAdmin', key: 0, level: 1 }
    },
    {
      path: '/institutions', name: 'Institutions', show: 1, panels: [0],
      meta: { title: 'Institutions', layout: AuthenticatedLayout, role: 'Admin', key: 0, level: 1 },
      children: [
        { 
          path: 'institutions', name: 'InstitutionsTable', show: 1,
          meta: { title: 'Institutions', layout: AuthenticatedLayout, role: 'Admin', key: 0, level: 2 }, 
          component: markRaw(Institutions),
        },
        { 
          path: 'types', name: 'InstitutionsTypesTable', show: 1,
          meta: { title: 'Institution Types', layout: AuthenticatedLayout, role: 'Admin', key: 0, level: 2 }, 
          component: markRaw(InstitutionTypes),
        },
        { 
          path: 'groups', name: 'InstitutionGroupsTable', show: 1,
          meta: { title: 'Institution Groups', layout: AuthenticatedLayout, role: 'Admin', key: 0, level: 2 }, 
          component: markRaw(InstitutionGroups),
        },
      ]
    },
    {
      path: '/users', name: 'Users', show: 1, panels: [0],
      meta: { title: 'Users', layout: AuthenticatedLayout, role: 'Admin', key: 0, level: 1 }, 
      children: [
        { 
          path: 'users', name: 'UserTable', show: 1,
          meta: { title: 'Users', layout: AuthenticatedLayout, role: 'Admin', key: 0, level: 2 }, 
          component: markRaw(Users),
        },
        { 
          path: 'roles', name: 'RolesTable', show: 1,
          meta: { title: 'Permissions', layout: AuthenticatedLayout, role: 'Admin', key: 0, level: 2 }, 
          component: markRaw(Roles),
        },
      ]
    },
    {
      path: '/credentials', name: 'Credentials', show: 1, panels: [],
      meta: { title: 'Credentials', layout: AuthenticatedLayout, role: 'Admin', key: 0, level: 1 }, 
      children: [
        { 
          path: 'credentials', name: 'CredentialsTable', show: 1,
          meta: { title: 'Credentials', layout: AuthenticatedLayout, role: 'Admin', key: 0, level: 2 }, 
          component: markRaw(Credentials),
        },
        { 
          path: 'audit', name: 'CredentialsAudit', show: 1,
          meta: { title: 'Credentials Audit', layout: AuthenticatedLayout, role: 'Admin', key: 0, level: 2 }, 
          component: markRaw(CredentialsAudit),
        },
      ],
    },
    {
      path: '/platforms', name: 'Platforms', show: 1,
      meta: { title: 'Platforms', layout: AuthenticatedLayout, role: 'Admin', key: 0, level: 1 },
      children: [
        { 
          path: 'registry', name: 'PlatformsTable', show: 1,
          meta: { title: 'Registry', layout: AuthenticatedLayout, role: 'ServerAdmin', key: 0, level: 2 }, 
          component: markRaw(Platforms),
        },
        { 
          path: 'connections', name: 'ConnectionsTable', show: 1,
          meta: { title: 'Connections', layout: AuthenticatedLayout, role: 'Admin', key: 0, level: 2 }, 
          component: markRaw(Connections),
        },
      ]
    },
    {
      path: '/harvests', name: 'Harvests',
      meta: { title: 'Harvests', layout: AuthenticatedLayout, role: 'Admin', key: 0, level: 1 },
      children: [
        { 
          path: 'manual', name: 'ManualHarvest', show: 1,
          meta: { title: 'Manual Harvest', layout: AuthenticatedLayout, role: 'Admin', key: 0, level: 2 }, 
          component: markRaw(ManualHarvest),
        },
        { 
          path: 'queue', name: 'HarvestQueue', show: 1,
          meta: { title: 'Harvest Queue', layout: AuthenticatedLayout, role: 'Admin', key: 0, level: 2 }, 
          component: markRaw(HarvestQueue),
        },
        { 
          path: 'log', name: 'HarvestLog', show: 1,
          meta: { title: 'Harvest Log', layout: AuthenticatedLayout, role: 'Admin', key: 0, level: 2 }, 
          component: markRaw(HarvestLog),
        },
      ]
    },
    {
      path: '/reports', name: 'Reports',
      meta: { title: 'Reports', layout: AuthenticatedLayout, role: 'Viewer', key: 0, level: 1 },
      children: [], component: markRaw(Reporting),
    },
    // ServerAdmin Config Routes
    { 
      path: '/server', name: 'Server',
      meta: { title: 'Server', layout: AuthenticatedLayout, role: 'ServerAdmin', key: 0, level: 1 }, 
      children: [
        { 
          path: 'settings', name: 'ServerSettings', show: 1,
          meta: { title: 'Server Settings', layout: AuthenticatedLayout, role: 'ServerAdmin', key: 0, level: 2 }, 
          component: markRaw(ServerSettings),
        },
        { 
          path: 'mailsettings', name: 'MailSettings', show: 1,
          meta: { title: 'Mail Settings', layout: AuthenticatedLayout, role: 'ServerAdmin', key: 0, level: 2 }, 
          component: markRaw(MailSettings),
        },
        { 
          path: 'api', name: 'CCPlusApi', show: 1,
          meta: { title: 'API Management', layout: AuthenticatedLayout, role: 'ServerAdmin', key: 0, level: 2 }, 
          component: markRaw(CCPlusApi),
        },
        { 
          path: 'account', name: 'AccountSettings', show: 1,
          meta: { title: 'Account Settings', layout: AuthenticatedLayout, role: 'Admin', key: 0, level: 2 }, 
          component: markRaw(AccountSettings),
        },
      ]
    }
];

// Separate routes that authenticatedLayout tacks onto the application routes in the top navigation bar
const profileRoute = {
    path: '/profile', name: 'Profile',
    meta: { title: 'Account Settings', layout: AuthenticatedLayout, role: 'Viewer', key: 0, level: 1 }, 
    component: markRaw(AccountSettings),
};

const apiRoute = {
    path: '/ccplusApi', name: 'API',
    meta: { title: 'CC-PLUS API', layout: AuthenticatedLayout, role: 'Viewer', key: 0, level: 1 }, 
    component: markRaw(CCPlusApi),
};

export const router = createRouter({
  history: createWebHistory(),
  routes,
  profileRoute,
  apiRoute
});

// Add router reference context directly to Pinia stores
pinia.use(({ store }) => {
  store.router = markRaw(router);
});

// Structural Navigation Guard
router.beforeEach(async (to, from) => {
  const authStore = useAuthStore(pinia);
  
  // Set the browser tab document title natively using the route name
  document.title = `${String(to.name || 'App')}`;

  // 1. Guest Route Checker
  if (to.meta.role !== 'Guest' && !authStore.isAuthenticated) {
    return { name: 'Login' }; 
  }

  // 2. Privilege Level Check
  if (to.meta.level > 0 && !authStore.user) {
    return '/api/login'; 
  }

// 3. Intercept and Handle Logout Routines
if (to.name === 'Logout') {
const { logout } = useAuthStore();
await logout();
}
});
// Sync Tab Layout Text Post-render
router.afterEach(to => {
document.title = "CC-Plus";
const ptitle = (to.meta.title) ? to.meta.title : '';
document.title += (ptitle.length > 0) ? ' - ' + ptitle : '';
});
export default router;