// resources/js/plugins/vuetify.js
import 'vuetify/styles'; // Framework layout grids mount natively here
import "vuetify/dist/vuetify-labs.css";
import '@mdi/font/css/materialdesignicons.css';
import { createVuetify } from 'vuetify';

export default createVuetify({
    // ─── NATIVE FRAMEWORK GLOBAL OVERRIDES ───
    // This replaces your old static Sass file token values cleanly!
    defaults: {
        VCard: {
            rounded: 'lg', // Automatically maps precisely to your uniform 8px card radius rules [components/cards]
        },
        VBtn: {
            style: 'font-size: 0.75rem; text-transform: none;' // Enforces your 12px layout text globally
        }
    },
    theme: { 
        defaultTheme: 'light',
        themes: {
            light: {
                dark: false,
                colors: {
                    background: '#66c018',    
                    surface: '#ffffff',       
                    primary: '#0066a1',       
                    secondary: '#3686b4',     
                    info: '#39aae0',          
                    error: '#dd0000',         
                    warning: '#ff9800',       
                    success: '#00dd00',       
                },
                variables: {
                    'font-family': "sans-serif",
                },
            },
        },
    },
});
