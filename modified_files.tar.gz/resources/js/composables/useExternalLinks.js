// composables/useExternalLinks.js
export function useExternalLinks() {
  const REGISTRY_BASE_URL = 'https://countermetrics.org';

  const LINKS = {
    github: 'https://github.com',
    onboarding: 'https://libwizard.com', 
    kyvlGuide: 'https://kyvl.org',       
    trialRequest: 'https://libwizard.com',
    demoEnv: 'https://kyvl.org',
    devEnv: 'https://kyvl.org',
    cop: 'https://countermetrics.org',
    counterApi: 'https://stoplight.io',
    registry: 'https://countermetrics.org',
    registryApi: 'https://countermetrics.orgapi/v1/?format=api',
    toolsServices: 'https://countermetrics.org',
    validator: 'https://countermetrics.orgvalidator/',
    ebscoBase: 'https://ebsco.com/',     
    celusInfo: 'https://counter51.info',
    exLibris: 'https://exlibrisgroup.com', 
    jiscFaq: 'https://jisc.ac.uk'
  };

  return {
    LINKS
  };
}
