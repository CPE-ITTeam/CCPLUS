<!-- layouts/AppHeader.vue -->
<script setup>
import { useAuthStore } from '@/plugins/authStore.js';
import { useExternalLinks } from '@/composables/useExternalLinks';
import AppLogo from "@/components/shared/AppLogo.vue"

const authStore = useAuthStore();
const { openCop, openCounterApi, openRegistry, openRegistryApi } = useExternalLinks();

function apiLogout() { 
  authStore.logout({}); 
}
</script>

<template>
  <v-toolbar color="#0066A1" class="px-4">
    <!-- Clean, semantic brand typography anchor alignment -->
    <template v-slot:prepend>
      <div class="bg-white rounded pa-1 d-flex align-center">
        <AppLogo :height="36" />
      </div>
    </template>

    <v-spacer></v-spacer>

    <!-- Repositioned actions list cleanly out of the title truncation block -->
    <div class="d-flex align-center ga-1">
      
      <!-- Logout Controller -->
      <v-btn id="logout-btn" icon="mdi-logout" @click="apiLogout"></v-btn>
      <v-tooltip activator="#logout-btn" location="bottom">Log out</v-tooltip>

      <!-- COUNTER External Links Menu Overlay Context -->
      <v-menu>
        <template v-slot:activator="{ props: menuProps }">
          <v-btn id="menu-btn" icon="mdi-dots-vertical" v-bind="menuProps"></v-btn>
          <v-tooltip activator="#menu-btn" location="bottom">COUNTER links</v-tooltip>
        </template>
        
        <v-list density="comfortable" width="220" border rounded="lg">
          <v-list-item @click="openCop" prepend-icon="mdi-file-document-outline">
            <v-list-item-title>Code of Practice</v-list-item-title>
          </v-list-item>
          
          <v-list-item @click="openCounterApi" prepend-icon="mdi-api">
            <v-list-item-title>COUNTER API</v-list-item-title>
          </v-list-item>
          
          <v-list-item @click="openRegistry" prepend-icon="mdi-database-outline">
            <v-list-item-title>Registry</v-list-item-title>
          </v-list-item>
          
          <v-list-item @click="openRegistryApi" prepend-icon="mdi-code-json">
            <v-list-item-title>Registry API</v-list-item-title>
          </v-list-item>
        </v-list>
      </v-menu>

    </div>
  </v-toolbar>
</template>
