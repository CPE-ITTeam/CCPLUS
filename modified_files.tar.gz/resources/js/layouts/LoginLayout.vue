<!-- layouts/LoginLayout.vue -->

<script setup>
import { reactive } from "vue"
import { useExternalLinks } from "@/composables/useExternalLinks"
import AppLogo from "@/components/shared/AppLogo.vue"

const { LINKS } = useExternalLinks()

const referenceMap = reactive({
  A: "A", B: "B", C: "C-G#C", D: "C-G#D", E: "C-G#E", F: "C-G#F", G: "C-G#G",
  H: "H", I: "I", J: "J",
  K: "K-P#K", L: "K-P#L", M: "K-P#M", N: "K-P#N", O: "K-P#O", P: "K-P#P",
  Q: null,
  R: "Q-S#R", S: "Q-S#S",
  T: "T-Z#T", U: "T-Z#U", V: "T-Z#V", W: "T-Z#W",
  X: null, Y: null,
  Z: "T-Z#Z"
})

// Bulletproof builder completely isolates the prefix and target anchor values
const buildEbscoUrl = (ref) => {
  if (!ref) return undefined
  
  const parts = ref.split("#")
  const prefix = parts[0]
  const anchor = parts[1] || ""
  
  const baseUrl = "https://connect.ebsco.com/s/article/Platform-Reference-List-" + prefix + "-Usage-Consolidation"
  const localeQuery = "?language=en_US"
  const elementHash = anchor ? "#" + anchor : ""
  
  return baseUrl + localeQuery + elementHash
}
</script>


<template>
  <v-app class="fill-height" style="min-height: 100vh;">
    <!-- 1. HEADER WITH NAVBAR -->
    <v-app-bar flat 
      class="bg-white px-4 border-b-thin border-solid border-opacity-100 border-primary">
      <div class="mt-5 mb-4">
        <AppLogo :height="40" />
      </div>

      <div class="ms-5 d-flex align-center ga-4">      
        <!-- Documentation -->
        <v-menu open-on-hover>
          <template #activator="{ props: menuProps }">
            <v-btn v-bind="menuProps" variant="text">Documentation</v-btn>
          </template>
          <v-list density="comfortable" border rounded="lg">
            <v-list-item title="Installation instructions" :href="LINKS.github" target="_blank" rel="noopener" />
            <v-divider />
            <v-list-item title="Institutional onboarding" :href="LINKS.onboarding" target="_blank" rel="noopener" />
            <v-list-item title="KYVL LibGuide (needs work)" :href="LINKS.kyvlGuide" target="_blank" rel="noopener" />
          </v-list>
        </v-menu>

        <!-- COUNTER Links -->
        <v-menu open-on-hover>
          <template #activator="{ props: menuProps }">
            <v-btn v-bind="menuProps" variant="text">COUNTER Links</v-btn>
          </template>
          <v-list density="comfortable" border rounded="lg">
            <v-list-item title="Code of Practice" :href="LINKS.cop" target="_blank" rel="noopener" />
            <v-divider />
            <v-list-item title="COUNTER API" :href="LINKS.counterApi" target="_blank" rel="noopener" />
            <v-divider />
            <v-list-item title="COUNTER Registry" :href="LINKS.registry" target="_blank" rel="noopener" />
            <v-list-item title="Registry API Root" :href="LINKS.registryApi" target="_blank" rel="noopener" />
            <v-divider />
            <v-list-item title="Tools and Services" :href="LINKS.toolsServices" target="_blank" rel="noopener" />
            <v-list-item title="Validator" :href="LINKS.validator" target="_blank" rel="noopener" />
          </v-list>
        </v-menu>

        <!-- URL Finder -->
        <v-menu open-on-hover>
          <template #activator="{ props: menuProps }">
            <v-btn v-bind="menuProps" variant="text">URL Finder</v-btn>
          </template>
          <v-list density="comfortable" border rounded="lg" width="320">
            <v-list-item title="EBSCO Master Platform List" :href="LINKS.ebscoBase" target="_blank" rel="noopener" />
            <v-list-item class="py-2">
              <div class="reference-list d-flex flex-wrap justify-start">
                <!-- COLON-BOUND :href processes the dynamic function value safely -->
                <v-chip 
                  v-for="(ref, letter) in referenceMap" 
                  :key="letter" 
                  :href="ref ? buildEbscoUrl(ref) : undefined"
                  :target="ref ? '_blank' : undefined" 
                  rel="noopener" 
                  :color="ref ? 'primary' : 'grey'" 
                  :variant="ref ? 'tonal' : 'outlined'" 
                  size="small" 
                  class="ma-1"
                >
                  {{ letter }}
                </v-chip>
              </div>
            </v-list-item>
            <v-divider />
            <v-list-item title="counter51.info - Celus" :href="LINKS.celusInfo" target="_blank" rel="noopener" />
            <v-list-item title="ExLibris SUSHI Vendor Lists" :href="LINKS.exLibris" target="_blank" rel="noopener" />
            <v-list-item title="JISC Counter 5 FAQ" :href="LINKS.jiscFaq" target="_blank" rel="noopener" />
          </v-list>
        </v-menu>

        <!-- Demo / Dev -->
        <v-menu open-on-hover>
          <template #activator="{ props: menuProps }">
            <v-btn v-bind="menuProps" variant="text">Demo / Dev</v-btn>
          </template>
          <v-list density="comfortable" border rounded="lg">
            <v-list-item title="Trial request" :href="LINKS.trialRequest" target="_blank" rel="noopener" />
            <v-divider />
            <v-list-item title="Demo" :href="LINKS.demoEnv" target="_blank" rel="noopener" />
            <v-list-item title="Dev" :href="LINKS.devEnv" target="_blank" rel="noopener" />
          </v-list>
        </v-menu>
      </div>
    </v-app-bar>

    <!-- 2. CORE VIEW -->
    <v-main class="d-flex flex-column">
      <div class="d-flex align-center justify-center flex-grow-1 w-100 pa-8">
        <router-view />
      </div>
    </v-main>

    <!-- 3. FOOTER -->
    <v-footer app
      class="bg-grey-lighten-4 border-t-thin border-solid border-opacity-100 border-primary py-4 d-flex justify-center w-100">
      <div class="footer-links">
        <a :href="LINKS.cop" target="_blank" rel="noopener" aria-label="Official COUNTER Code of Practice website">
          <img src="https://countermetrics.org" alt="COUNTER Metrics Logo" />
        </a>
        <a :href="LINKS.registry" target="_blank" rel="noopener" aria-label="Official COUNTER Registry portal">
          <img src="https://countermetrics.org" alt="COUNTER Registry Logo" />
        </a>
        <a :href="LINKS.github" target="_blank" rel="noopener" aria-label="CCPLUS GitHub open source repository">
          <img src="https://githubassets.com" alt="GitHub Logo" />
        </a>
      </div>
    </v-footer>
  </v-app>
</template>

<style scoped>

.footer-links {
  display: flex;
  align-items: center;
  gap: 1.5rem;
}
.footer-links a {
  display: inline-block;
  flex-shrink: 0;
}
:deep(.footer-links img) {
  height: 28px !important;
  width: auto !important;
  display: block;
}
</style>
