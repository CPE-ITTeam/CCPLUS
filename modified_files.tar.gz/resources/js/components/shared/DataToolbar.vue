<!-- components/shared/DataToolbar.vue -->
<script setup>
  import { ref, computed } from 'vue';
  import { storeToRefs } from 'pinia';
  import { useAuthStore } from '@/plugins/authStore.js';
  import { useCCPlusStore } from '@/plugins/CCPlusStore.js';
  import SearchAndSelect from './SearchAndSelect.vue';
  import ToolbarFilters from './ToolbarFilters.vue';
  import BulkActions from './BulkActions.vue';
  import ExportAndImport from './ExportAndImport.vue';
  import ImportDialog from '@/components/dialogs/ImportDialog.vue';
  const filter_options = defineModel({type: Array, required: true});
  const props = defineProps({
    search: { type: String, required: true },
    showSelectedOnly: { type: Boolean, required: true },
    dataset: { type: String, required: true },
    selectedRows: { type: Array, required: true },
    bulkOptions: { type: Object, required: true },
    hideExport: { type: Boolean, required: true },
  });

  const authStore = useAuthStore();
  const { consortia } = storeToRefs(useCCPlusStore());
  const is_serveradmin = authStore.is_serveradmin;
  var consoKey = ref(authStore.ccp_key);
  const importDialog = ref(false);

  const serverTab = computed(() => {
    return (props.dataset=='consortia' || props.dataset=='platforms');
  });

  const consoOnly = computed(() => {
    return (consoKey.value == '' && is_serveradmin);
  });

  const needsRefreshButton = computed(() => {
    return (props.dataset=='harvests' || props.dataset=='jobs' || props.dataset=='audit');
  });

  const showExportImport = computed(() => {
    return (props.dataset=='consortia' || (!consoOnly.value && props.dataset!='harvests' && props.dataset!='jobs'));
  });

  const flat_filter_options = computed(() => {
    let _options = {};
    filter_options.value.forEach( (row,idx) => {
      for (const key of Object.keys(row)) {
        _options[key] = {...filter_options.value[idx][key]};
      };
    });
    return _options;
  });

  const anyFilterSet = computed(() => {
    if (props.selectedRows.length>0) return true;
    var is_set = false;
    for (const key of Object.keys(flat_filter_options.value)) {
      const filter = flat_filter_options.value[key];
      if (!filter.show) continue;
      if ( Array.isArray(filter.value) ) {
        if (filter.value.length > 0) is_set = true;
      } else if (filter.type == 'toggle') {
        is_set = (filter.value == 'Active');
      } else if (filter.value) {
        is_set = true;
      }
      if (is_set) break;
    }
    return is_set;
  });

  function handleFilter(filt) {
    // update filter by finding it in the filter_options rows
    let updated = false;
    filter_options.value.forEach( (row,idx) => {
      if (updated || typeof(filter_options.value[idx][filt.key]) == 'undefined') return;
      filter_options.value[idx][filt.key]['value'] = filt.value;
      updated = true;
    });
    if (updated) emit('setFilter', filt);
  }

  function handleImported(data) {
    emit('imported', data);
    importDialog.value = false;
  }

  const emit = defineEmits([
    'updateConso',
    'update:search',
    'update:showSelectedOnly',
    'add',
    'export',
    'imported',
    'setFilter',
    'bulkAction',
    'refreshRecords'
  ]);
</script>


<template>
  <v-card variant="outlined" class="pa-4 mb-4">
    
    <!-- HEADER LAYER: Segmented Titles lock flat to the left border of their inputs below -->
    <div class="d-flex align-center ga-3 w-100 mb-2">
      <!-- 1. Consortium Title Zone (Only takes space if the input exists below) -->
      <div 
        v-if="!serverTab && (is_serveradmin && consortia.length > 1)" 
        style="width: 200px;" 
        class="flex-shrink-0"
      >
        <span class="text-caption text-uppercase font-weight-bold tracking-wider text-medium-emphasis">
          Consortium
        </span>
      </div>

      <!-- 2. Search Title Zone (Only takes space if the input exists below) -->
      <div 
        v-if="!consoOnly || is_serveradmin" 
        style="width: 280px;" 
        class="flex-shrink-0"
      >
        <span class="text-caption text-uppercase font-weight-bold tracking-wider text-medium-emphasis">
          Search
        </span>
      </div>
      
<!-- 3. Filters Title Zone: Only renders on-screen if filter_options exist -->
<div 
  v-if="filter_options && filter_options.length > 0"
  class="d-flex justify-start align-center ga-3 flex-grow-1"
>
  <!-- Native Length Check swaps between singular 'FILTER' and plural 'FILTERS' dynamically -->
  <span class="text-caption text-uppercase font-weight-bold tracking-wider text-medium-emphasis">
    {{ filter_options.length > 1 ? 'Filters' : 'Filter' }}
  </span>
  
  <!-- Clean, crisp Red Text Link with no background padding shapes -->
  <v-btn 
    v-if="anyFilterSet"
    prepend-icon="mdi-restore" 
    color="error" 
    variant="text" 
    size="small"
    density="comfortable"
    class="text-caption font-weight-bold text-uppercase px-0"
    style="letter-spacing: normal; min-width: auto;"
    @click="$emit('setFilter', { key: 'reset' })"
  >
    Reset
  </v-btn>
</div>

    </div>

    <!-- TIER 1: UNIFIED INPUT GROUP -->
    <div class="d-flex flex-wrap align-center ga-3 w-100 mb-3">
      
      <!-- Consortium Switcher (Width: 200px) -->
      <div v-if="!serverTab && (is_serveradmin && consortia.length > 1)" style="width: 200px;" class="flex-shrink-0">
        <v-autocomplete 
          v-model="consoKey" 
          label="Consortium" 
          :items="consortia" 
          item-title="name" 
          item-value="ccp_key"
          variant="outlined"
          hide-details="auto"
          return-object 
          @update:modelValue="$emit('updateConso', $event)" 
        />
      </div>

      <!-- Search Input (Width: 280px) -->
      <div v-if="!consoOnly || is_serveradmin" style="width: 280px;" class="flex-shrink-0">
        <SearchAndSelect 
          :search="search" 
          @update:search="$emit('update:search', $event)"
        />
      </div>

      <!-- Dynamic Data Filters Loop -->
      <div 
        v-for="(row, index) in filter_options" 
        :key="index" 
        class="d-flex flex-wrap ga-3 flex-grow-1"
      >
        <ToolbarFilters :filters="filter_options[index]" @setFilter="handleFilter($event)" />
      </div>

      <!-- System Utility Action -->
      <div class="ms-auto flex-shrink-0">
        <v-btn 
          v-if="needsRefreshButton && consoKey != ''" 
          color="primary" 
          variant="flat"
          @click="$emit('refreshRecords')"
        >
          Refresh Records
        </v-btn>
      </div>

    </div>

    <!-- TIER 2: UNIFIED ACTIONS BAR -->
    <v-divider class="my-3" />
    <div class="d-flex flex-wrap align-center justify-space-between ga-4 w-100 pt-1">
      
      <!-- LEFT SIDE: Contextual Bulk Operations Area -->
      <div class="d-flex align-center ga-3" style="min-height: 40px; min-width: 360px;">
        <v-expand-x-transition>
          <div v-if="props.selectedRows.length > 0 && props.bulkOptions.items.length > 0" class="d-flex align-center ga-3 w-100">
            
            <v-tooltip :text="showSelectedOnly ? 'Show All' : 'Show Selected'" location="top">
              <template #activator="{ props: tooltipProps }">
                <v-btn 
                  v-bind="tooltipProps" 
                  icon 
                  color="primary" 
                  size="large"
                  class="flex-shrink-0"
                  :variant="showSelectedOnly ? 'outlined' : 'tonal'"
                  @click="$emit('update:showSelectedOnly', !showSelectedOnly)"
                >
                  <v-icon>{{ showSelectedOnly ? 'mdi-filter-off' : 'mdi-filter' }}</v-icon>
                </v-btn>
              </template>
            </v-tooltip>

            <BulkActions 
              v-model="props.bulkOptions" 
              style="width: 280px;"
              @bulkAction="$emit('bulkAction', $event)" 
            />
            
          </div>
        </v-expand-x-transition>
      </div>

      <!-- RIGHT SIDE: Permanent Action Buttons -->
      <div class="d-flex align-center flex-wrap ga-2 ms-auto">
        <ExportAndImport 
          v-if="showExportImport" 
          :showRefresh="props.dataset == 'platforms'"
          :exportOnly="(props.dataset == 'audit')" 
          :hideExport="props.hideExport"
          @export="$emit('export')" 
          @import="importDialog = true" 
          @add="$emit('add')"
          @refresh="$emit('bulkAction', { action: 'Full Refresh' })"
        />
      </div>

    </div>

    <!-- Overlays -->
    <v-dialog v-model="importDialog" max-width="500">
      <ImportDialog :dataset="props.dataset" @close="importDialog = false" @imported="handleImported" />
    </v-dialog>
  </v-card>
</template>
