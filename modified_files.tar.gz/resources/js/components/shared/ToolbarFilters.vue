<script setup>
import MultiSelectCombobox from './MultiSelectCombobox.vue';
import ToggleIcon from '@/components/shared/ToggleIcon.vue';

const props = defineProps({
  filters: { type: Object, required: true },
});

const emit = defineEmits(['setFilter']);

function handleFilter(filt) {
  emit('setFilter', { key: filt.name, value: filt.value });
}
</script>

<!-- shared/ToolbarFilters.vue -->
<template>
  <!-- 
    1. Added align-center to force all mixed field heights onto a single horizontal centerline.
    2. Added h-100 rules to the loop cells to lock their layout grids together perfectly.
  -->
  <div class="d-flex flex-row flex-wrap align-center ga-3 w-100 pt-2">
    <div 
      v-for="(filter, idx) in props.filters" 
      :key="idx" 
      class="flex-shrink-0 d-flex align-center"
      style="width: calc(25% - 12px); min-width: 240px; max-width: 300px; min-height: 56px;"
    >

      <!-- Toggle filter case -->
      <div v-if="filter.show && filter.type == 'toggle'" class="d-flex align-center h-100 pl-2">
        <ToggleIcon 
          v-model="props.filters[filter.name].value" 
          :label="filter.label"
          toggleable 
          :size="36" 
          @update:modelValue="handleFilter(filter)" 
        />
      </div>

      <!-- 
        Pass style="width: 100%;" onto your inputs inside the loop cells.
        This forces the child components to stretch flush to the boundaries 
        of our unified flex layout grid blocks.
      -->
      <MultiSelectCombobox 
        v-else-if="filter.show && filter.type == 'mselect'" 
        v-model="props.filters[filter.name].value" 
        :label="filter.label"
        multiple 
        :items="filter.items" 
        :item-title="filter.txt" 
        :item-value="filter.val" 
        variant="outlined"
        hide-details="auto"
        style="width: 100%;"
        @update:modelValue="handleFilter(filter)" 
      />

      <v-autocomplete 
        v-else-if="filter.show && filter.type == 'select'" 
        v-model="props.filters[filter.name].value" 
        :label="filter.label"
        :items="filter.items" 
        :item-title="filter.txt" 
        :item-value="filter.val" 
        variant="outlined"
        hide-details="auto"
        style="width: 100%;"
        @update:modelValue="handleFilter(filter)" 
      />

      <MultiSelectCombobox 
        v-else-if="filter.show && filter.type == 'mtext'" 
        v-model="props.filters[filter.name].value" 
        :label="filter.label"
        :items="filter.items" 
        multiple 
        variant="outlined"
        hide-details="auto"
        style="width: 100%;"
        @update:modelValue="handleFilter(filter)" 
      />

      <v-select 
        v-else-if="filter.show && filter.type == 'text'" 
        v-model="props.filters[filter.name].value" 
        :label="filter.label"
        :items="filter.items" 
        variant="outlined"
        hide-details="auto"
        style="width: 100%;"
        @update:modelValue="handleFilter(filter)" 
      />

    </div>
  </div>
</template>
