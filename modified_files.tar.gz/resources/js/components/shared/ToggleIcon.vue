<!-- components/shared/ToggleIcon.vue -->
<script setup>
import { computed } from 'vue';
import { useAuthStore } from '@/plugins/authStore.js';

const props = defineProps({
  modelValue: {
    type: [String, Object, Boolean],
    required: true,
    validator: (value) => value !== undefined
  },
  label: { type: String, default: '' },
  toggleable: { type: Boolean },
  size: { type: [Number, String], default: 32 }
});

const emit = defineEmits(['update:modelValue']);
const authStore = useAuthStore();

// ─────────────────────────────────────────────────────────────────────────
// 1. SEMANTIC CONFIGURATION MAP: Replaced hardcoded HEX with semantic names
// ─────────────────────────────────────────────────────────────────────────
const defaultMap = {
  Active:     { icon: 'mdi-toggle-switch',     color: 'success' },
  Enabled:    { icon: 'mdi-toggle-switch',     color: 'success' },
  true:       { icon: 'mdi-toggle-switch',     color: 'success' },
  Inactive:   { icon: 'mdi-toggle-switch-off', color: 'error' },
  Disabled:   { icon: 'mdi-toggle-switch-off', color: 'error' },
  false:      { icon: 'mdi-toggle-switch-off', color: 'error' },
  Incomplete: { icon: 'mdi-toggle-switch-off', color: 'warning' },
  Suspended:  { icon: 'mdi-toggle-switch-off', color: 'medium-emphasis' }
};

const isObjectValue = computed(() => typeof props.modelValue === 'object' && props.modelValue !== null);

const can_admin = computed(() => {
  if (!isObjectValue.value) return false;
  const matchInsts = authStore.admin_insts.some(ii => props.modelValue.insts?.includes(ii));
  const matchGroups = authStore.admin_groups.some(gg => props.modelValue.groups?.includes(gg));
  return authStore.is_conso_admin || matchInsts || matchGroups;
});

const meta = computed(() => {
  if (!isObjectValue.value) {
    // Falls back cleanly to theme-aware neutrals if unmapped
    const entry = defaultMap[String(props.modelValue)] || { icon: 'mdi-help-circle', color: 'disabled' };
    return { ...entry, clickable: props.toggleable ?? false };
  }

  const { conso, available, requested } = props.modelValue;

  if (!available) {
    return { icon: 'mdi-minus-box-outline', color: 'disabled', clickable: false };
  }

  if (conso) {
    return { 
      icon: 'mdi-checkbox-multiple-marked', 
      color: authStore.is_conso_admin ? 'success' : 'medium-emphasis', 
      clickable: authStore.is_conso_admin 
    };
  }

  if (requested) {
    return { 
      icon: 'mdi-checkbox-marked-outline', 
      color: can_admin.value ? 'success' : 'medium-emphasis', 
      clickable: can_admin.value 
    };
  }

  return { 
    icon: 'mdi-plus-box-outline', 
    color: authStore.is_admin ? 'success' : 'medium-emphasis', 
    clickable: authStore.is_admin 
  };
});

const tooltip = computed(() => {
  if (!isObjectValue.value) return String(props.modelValue);

  const { conso, available, requested } = props.modelValue;
  if (!available) return 'Unavailable';
  if (conso) return 'Connected for Consortium';
  if (requested) return 'Connected for 1+ institutions';
  return 'Click to Request';
});

function handleClick() {
  if (!meta.value.clickable) return;
  
  if (!isObjectValue.value) {
    const valStr = String(props.modelValue);
    const toggles = {
      'Active': 'Inactive', 'Inactive': 'Active',
      'Enabled': 'Disabled', 'Disabled': 'Enabled',
      'true': 'false', 'false': 'true',
    };
    const next = toggles[valStr];
    if (next !== undefined) {
      // Cast back to boolean natively if incoming state was primitive boolean
      const output = next === 'true' ? true : next === 'false' ? false : next;
      emit('update:modelValue', output);
    }
    return;
  }

  emit('update:modelValue', { ...props.modelValue });
}
</script>

<template>
  <!-- 
    NATIVE ACCESSIBILITY FIX:
    Wrapped inside a semantic button tag if clickable, so keyboard tab navigators 
    and screen reader accessibility loops don't skip over it (WCAG 2.1 AA requirement).
  -->
  <button
    type="button"
    :disabled="!meta.clickable"
    :title="tooltip"
    class="d-inline-flex align-center justify-start text-left border-none bg-transparent pa-0 text-none custom-toggle-btn"
    :class="{ 'cursor-pointer': meta.clickable, 'cursor-default': !meta.clickable }"
    @click="handleClick"
  >
    <!-- 1. The Toggle Switch Icon renders FIRST -->
    <!-- Passing semantic names to :color makes it read directly from plugins/vuetify.js -->
    <v-icon 
      :icon="meta.icon" 
      :color="meta.color" 
      :size="size" 
      class="flex-shrink-0"
    />
    
    <!-- 2. The Text Label renders SECOND (Only if present) -->
    <span v-if="props.label !== ''" class="ms-2 text-body-2 font-weight-medium text-medium-emphasis">
      {{ props.label }}
    </span>
  </button>
</template>

<style scoped>
.custom-toggle-btn {
  outline: none;
  color: inherit;
}
/* WCAG Focus ring only triggers when focused via keyboard tab actions */
.custom-toggle-btn:focus-visible {
  outline: 2px solid rgb(var(--v-theme-primary));
  border-radius: 4px;
}
</style>
